﻿namespace EcoDataManager
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_browse = new System.Windows.Forms.Button();
            this.btn_xml = new System.Windows.Forms.Button();
            this.btn_csv = new System.Windows.Forms.Button();
            this.btn_json = new System.Windows.Forms.Button();
            this.txtb_filename = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_browse
            // 
            this.btn_browse.Location = new System.Drawing.Point(521, 101);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(75, 38);
            this.btn_browse.TabIndex = 0;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // btn_xml
            // 
            this.btn_xml.Location = new System.Drawing.Point(82, 173);
            this.btn_xml.Name = "btn_xml";
            this.btn_xml.Size = new System.Drawing.Size(75, 38);
            this.btn_xml.TabIndex = 1;
            this.btn_xml.Text = "XML";
            this.btn_xml.UseVisualStyleBackColor = true;
            this.btn_xml.Click += new System.EventHandler(this.btn_xml_Click);
            // 
            // btn_csv
            // 
            this.btn_csv.Location = new System.Drawing.Point(183, 173);
            this.btn_csv.Name = "btn_csv";
            this.btn_csv.Size = new System.Drawing.Size(75, 38);
            this.btn_csv.TabIndex = 2;
            this.btn_csv.Text = "CSV";
            this.btn_csv.UseVisualStyleBackColor = true;
            this.btn_csv.Click += new System.EventHandler(this.btn_csv_Click);
            // 
            // btn_json
            // 
            this.btn_json.Location = new System.Drawing.Point(289, 173);
            this.btn_json.Name = "btn_json";
            this.btn_json.Size = new System.Drawing.Size(75, 38);
            this.btn_json.TabIndex = 3;
            this.btn_json.Text = "JSON";
            this.btn_json.UseVisualStyleBackColor = true;
            this.btn_json.Click += new System.EventHandler(this.btn_json_Click);
            // 
            // txtb_filename
            // 
            this.txtb_filename.Location = new System.Drawing.Point(82, 101);
            this.txtb_filename.Name = "txtb_filename";
            this.txtb_filename.Size = new System.Drawing.Size(416, 26);
            this.txtb_filename.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 531);
            this.Controls.Add(this.txtb_filename);
            this.Controls.Add(this.btn_json);
            this.Controls.Add(this.btn_csv);
            this.Controls.Add(this.btn_xml);
            this.Controls.Add(this.btn_browse);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Button btn_xml;
        private System.Windows.Forms.Button btn_csv;
        private System.Windows.Forms.Button btn_json;
        private System.Windows.Forms.TextBox txtb_filename;
    }
}

