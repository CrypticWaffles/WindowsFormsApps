﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace EcoDataManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            DialogResult result = openFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string file = openFileDialog.FileName;
                txtb_filename.Text = file;
            }
        }

        private void btn_xml_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=BIG-PP-9000\SQLEXPRESS;Initial Catalog=LoginDB;Integrated Security=True;TrustServerCertificate=True";
            SqlConnection connection = new SqlConnection(connectionString);
            DataSet ds = new DataSet();
            XmlReader xmlFile;

            int id;
            string first_name, last_name, email, gender, country;
            string query = "INSERT INTO Sellers (ID, first_name, last_name, email, gender, country) VALUES(@id, @first_name, @last_name, @email, @gender, @country);";
            string file = txtb_filename.Text.ToString();

            xmlFile = XmlReader.Create(file, new XmlReaderSettings());
            ds.ReadXml(xmlFile);

            connection.Open();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                id = Convert.ToInt32(ds.Tables[0].Rows[i].ItemArray[0]);
                first_name = ds.Tables[0].Rows[i].ItemArray[1].ToString();
                last_name = ds.Tables[0].Rows[i].ItemArray[2].ToString();
                email = ds.Tables[0].Rows[i].ItemArray[3].ToString();
                gender = ds.Tables[0].Rows[i].ItemArray[4].ToString();
                country = ds.Tables[0].Rows[i].ItemArray[5].ToString();
                
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@first_name", first_name);
                cmd.Parameters.AddWithValue("@last_name", last_name);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@country", country);
                cmd.ExecuteNonQuery();
            }
            connection.Close();
        }

        private void btn_csv_Click(object sender, EventArgs e)
        {
            string file = txtb_filename.Text.ToString();

            DataTable csvData = getDataDromCSV(file);

            InsertDataIntoSQL(csvData);
        }

        private static DataTable getDataDromCSV(string file)
        {
            DataTable data = new DataTable();
            try
            {
                using(TextFieldParser csvReader = new TextFieldParser(file))
                {
                    csvReader.SetDelimiters(",");
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    // Add Columns
                    foreach (string  colField in colFields)
                    {
                        DataColumn datacolumn = new DataColumn(colField);
                        data.Columns.Add(datacolumn);
                    }
                    // Add Rows
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        data.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.ToString());
            }

            return data;
        }

        private static void InsertDataIntoSQL(DataTable dataTable)
        {
            using (SqlConnection dbConnection = new SqlConnection(@"Data Source=BIG-PP-9000\SQLEXPRESS;Initial Catalog=LoginDB;Integrated Security=True;TrustServerCertificate=True"))
            {
                dbConnection.Open();
                using(SqlBulkCopy s = new SqlBulkCopy(dbConnection))
                {
                    s.DestinationTableName = "Emails";
                    foreach (var column in dataTable.Columns)
                    {
                        s.ColumnMappings.Add(column.ToString(), column.ToString());
                    }
                    s.WriteToServer(dataTable);
                }
                dbConnection.Close();
            }
        }

        private void btn_json_Click(object sender, EventArgs e)
        {

        }
    }
}
